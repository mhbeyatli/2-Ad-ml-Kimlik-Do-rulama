TWO FACTOR AUTHENTICATION

Necessary files that contains algorithm in:
main\java\Activities
main\res\layout

