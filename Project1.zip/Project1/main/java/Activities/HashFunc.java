package ch.zhaw.facerecognition.Activities;

/**
 * Created by berkan on 14.10.2017.
 */

public class HashFunc { //Hash function for hashing passwords
    public static long hashFunction(String input){
        long x = 1;
        for (int i = 0; i < input.length(); i++){
            x *= input.charAt(i);
        }
        return x;
    }
}
