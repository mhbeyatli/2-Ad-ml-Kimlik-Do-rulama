/* Copyright 2016 Michael Sladoje and Mike Schälchli. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

package ch.zhaw.facerecognition.Activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;

import ch.zhaw.facerecognitionlibrary.Helpers.FileHelper;
import ch.zhaw.facerecognition.R;

public class SignUpActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        Button btn_Photo = (Button)findViewById(R.id.btn_Photo);    //Button call for taking photos
        btn_Photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText txt_Username = (EditText)findViewById(R.id.txt_Username);  //Username call from the editText
                String username = txt_Username.getText().toString();
                EditText txt_Password = (EditText)findViewById(R.id.txt_Password);  //Password call from the editText
                String password = txt_Password.getText().toString();
                Intent intent = new Intent(v.getContext(), AddPersonPreviewActivity.class); //Intent for add person operation
                intent.putExtra("Username", username);
                intent.putExtra("Password", password);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                if(isNameAlreadyUsed(new FileHelper().getTestList(), username)) {   //Control for duplicated username
                    Toast.makeText(getApplicationContext(), "This name is already used. Please choose another one.", Toast.LENGTH_SHORT).show();
                } else if(username.length() < 4 || password.length() < 4){ //Control for username/password size
                    Toast.makeText(getApplicationContext(), "Username or password is too short!", Toast.LENGTH_SHORT).show();
                } else {    //Succesfull entry
                    intent.putExtra("Folder", "Images");
                    startActivity(intent);
                }
            }
        });
    }

    private boolean isNameAlreadyUsed(File[] list, String name){
        boolean used = false;
        if(list != null && list.length > 0){
            for(File person : list){
                // The last token is the name --> Folder name = Person name
                String[] tokens = person.getAbsolutePath().split("/");
                final String foldername = tokens[tokens.length-1];
                if(foldername.equals(name)){
                    used = true;
                    break;
                }
            }
        }
        return used;
    }
}
