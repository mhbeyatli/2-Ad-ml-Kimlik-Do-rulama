/* Copyright 2016 Michael Sladoje and Mike Schälchli. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

package ch.zhaw.facerecognition.Activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import ch.zhaw.facerecognition.R;

public class WelcomeActivity extends Activity { //Welcome page activity

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        Intent intent = getIntent();
        String username = intent.getStringExtra("Username");    //Taking entered username and password
        String password = intent.getStringExtra("Password");
        String foundNameGroup = intent.getStringExtra("FoundNameGroup");    //Taking found name group from recognition activity
        String [] elements = foundNameGroup.split("½"); //Spliting the found elements
        String foundUsername = elements[0];
        String foundPassword = elements[1];
        long hashedPassword = HashFunc.hashFunction(password);  //Hashing the entered password for control
        String hashedPasswordStr = String.valueOf(hashedPassword);
        if(username.equalsIgnoreCase(foundUsername) && hashedPasswordStr.equalsIgnoreCase(foundPassword)){  //Control for correct username/password
            TextView textview = (TextView)findViewById(R.id.textView2);
            textview.setText(username);
            Button btn_quit = (Button)findViewById(R.id.btn_quit);
            btn_quit.setOnClickListener(new View.OnClickListener() {    //Quiting from page
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(v.getContext(), MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
            });
        }
        else{   //Wrong password/username warning
            Toast.makeText(getApplicationContext(), "Invalid Username/Password/Face entry", Toast.LENGTH_SHORT).show();
            Intent intent2 = new Intent(getApplicationContext(), SignInActivity.class);
            startActivity(intent2);
        }
    }
}
